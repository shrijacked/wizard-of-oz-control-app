# AAMAS paper refresh — 8 October 2026

Editable source: `main.tex`. Checked preview: `main.pdf`. Original baseline: writing commit `5fe730d`, preserved in `../fetched-writing/`; earlier local package in `../backup-current-paper/`. Previous refresh pushed as `ab96ee4`. The complete pre-photo-edit version is preserved in `../revisions/2026-10-08-setup-layout/before/`. The author authorized pushing the latest setup/quote-layout changes to `writing`; Git history records the actual commit.

This manuscript is cleaned for final-draft review. Separate substantive and submission considerations are in `../FINAL_DRAFT_REVIEW.md`; they are not author placeholders inside the manuscript. Participant mix: mostly undergraduates, with faculty and graduate students/researchers. Ages20–27, mean21.96, SD2.01. Gender totals14 men/10 women (58.3%/41.7%); raw individual fields unchanged. No institutional approval or exemption is claimed.

## Data and interpretation

24 participants and216 rounds contribute all primary task, duration, workload and assistance-rating analyses. Completion is11/72 control,43/72 constant,36/72 adaptive. Final-survey summaries include15 responses. Earlier exclusion analyses remain internal sensitivities. Scoring maximizes count across admissible orientations; counts were noted and photographed. Formative assessment:50 substantive responses,Username/email removed. Samples partly overlap.

Both assistance policies improve correct-piece progress, confirmed completion and adapted workload versus control. Adaptive-control frustration survives secondary-family Holm correction; adaptive-constant does not. No assisted-policy contrast survives its stated correction. Nonsignificance does not establish equivalence.

Analysis, raw/adjusted p values, CIs, effect sizes, sensitivity tests and TLX calculation: `../analysis/ANALYSIS.md`, `statistics.json` and `paired-tests.csv`. Reproduce with `../analyse-refresh.py` and `../render-results.py`; runtime instructions in `../README.md`. Original exports and workbook are not rewritten.

## Sources and changes

`../CHANGELOG.md` records decisions; `../changes.diff` compares current TeX/BibTeX with the writing baseline. `../citation-verification/ALL_SOURCE_AUDIT.md` reviews all 34 sources directly against their PDFs; `all-source-downloads.json` records evidence pointers, versions, hashes and citation locations. This is claim-level checking, not a claim that every page was read. Downloaded reference PDFs remain outside the lean source ZIP. Earlier copied support notes in `../legacy-writing-support/` are historical, not current analysis.

Seven figures and three tables integrate the architecture, OWL63 model, setup photographs, balanced-order tree, compact formative graph and statistical plots. Figure3 gives70% of the width to the schematic and28% to a vertically centered stack: smaller IMG_3103 rear-view setup photograph (76% of column width), operator dashboard, overhead workspace photo. The added JPEG has EXIF/location metadata removed; cropping uses LaTeX trim/clip only. Introduction carries more of the motivation; Related Work is shorter with all34 references retained and their claim alignment rechecked. Compact findings tables stay beside their introducing text; requested bold condition means remain without caption explanations. Contributions number three. Original abstract framing and numerical results are unchanged. Both original final-survey quotations remain anonymous, with normalized punctuation and bracketed grammar corrections. Latest snapshot: `../revisions/2026-10-08-quote-layout/before/`. The manuscript contains no unavailable-role notes, participant IDs or confirmation-history prose.

The lean source ZIP includes `review/` copies of the current change log, all-source audit/download manifest, analysis report and paired-test CSV. Full reference PDFs and raw participant inputs stay outside it. Audit PDF links resolve only in the local `citation-verification/` folder, not inside this source ZIP. Checked preview: eight pages, body ends on page7 and references on page8. Page3 has no former large gap; class, margins and body font are unchanged. Check photograph publication consent before external release.

See `author-notes.md` for unresolved facts and `BUILD.txt` for compilation/QA. Class, style, margins and body font are unchanged. Select `main.tex` in Overleaf; the pdfLaTeX route is documented but not independently tested locally.
