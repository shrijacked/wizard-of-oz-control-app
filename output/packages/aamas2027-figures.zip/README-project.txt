Place the six compile assets in figures/ relative to main.tex. Standalone diagram TeX and PNG previews are also included.
